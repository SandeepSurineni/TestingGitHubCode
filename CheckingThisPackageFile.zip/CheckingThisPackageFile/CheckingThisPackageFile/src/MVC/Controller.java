package MVC;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

public class Controller implements ActionListener {
	GUI gui; // creates a GUI object
	InventoryManager invManager;

	
	public void setGUI(GUI g) // connects to the GUI
	{
		gui = g;
	}

	public Controller() {
		invManager = new InventoryManager(); // creates an InventoryManager object
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {

	}

	// method to get the names
	public String[] getitemsnames() {
		return invManager.getitemnames();
	}
	
	public int getSize() {
		return invManager.getSize();
	}

}
