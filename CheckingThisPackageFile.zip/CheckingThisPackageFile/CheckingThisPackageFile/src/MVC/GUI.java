/*
 * INTERFACE FOR DISPLAYING ITEMS, THE SHOPPING CART 
 * DISPLAYING ITEMS SELECTED,
 * A PURCHASE MENU/ANNOUCEMENT, UPDATED INVENTORY DATA.
 * 
 * PANELS: 'LIST OF ITEMS' PANE THAT DISPLAYS ITEMS LIST.
 * SELECTING AN ITEM SHOULD DISPLAY IN A DIFF PANE WITH 
 * 'DESCRIPTION' AND UNIT PRICE
 * 		'CART' PANE THAT DISPLAYS THE ITEMS PURCHASED TOGETHER
 * 			WITH UNIT PRICE AND COST OF PURCHASE**UPDATES AFTER
 * 			EVERY ITEM
 * 
 * BUTTONS: 'ADD TO CART' (PURCHASE) - CLICKING PROMPTS FOR NUMBER OF ITEMS
 * 			'BUY' - CLICKING OUTPUT MESSAGE "Thanks for shopping 
 * 					with us. Your total cost is $ xxxx. Please
 * 					make arrangements for payment."
 * 			'COMPLETE'- items purchased listed again with message:
 * 					"These will be delivered to you. Thanks again.
 * 					Have a nice day."
 * 			'EXIT' - both on list of items, and CART window.
 */
package MVC;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.*;

import Apps.ProductDatabaseRead;

public class GUI extends JFrame {
//	InventoryManager inv = new InventoryManager();

	Controller listener; // declaring a controller

	String[] names; // declaring a string array

	ButtonGroup group = new ButtonGroup(); // creating the button group

	JButton addToCart, complete, exit;
	JPanel listPanel = new JPanel(), cartPanel = new JPanel();
	JPanel itemDesPanel = new JPanel();
	JButton[] buttons;

	public GUI() // constructor
	{

		addToCart = new JButton("Add To Cart");
		exit = new JButton("Exit");
		complete = new JButton("Complete Purchase");

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(400, 400));
		Container canvas = this.getContentPane();

		canvas.setLayout(new FlowLayout());
		canvas.add(listPanel);
		canvas.add(itemDesPanel);
		canvas.add(cartPanel);

		canvas.add(addToCart);
		canvas.add(exit);
		canvas.add(complete);

		// listPanel.setPreferredSize(new Dimension(100,300));
		// listPanel.setBorder(BorderFactory.createLineBorder(Color.red));

		this.pack();
		this.setVisible(true);

	}

	public void setlistener(Controller c) // setting the listener for the different buttons
	{
		listener = c;
	}

	public void setNames(String[] n) // setting the names onto the panels
	{
		// ProductDatabaseRead pdr = new ProductDatabaseRead();
		// buttons = new JButton[n.length];
		// System.out.println(n.length);
		buttons = new JButton[listener.getSize()];
		for (int i = 0; i < listener.getSize(); i++) {
			buttons[i] = new JButton(n[i]);
			listPanel.add(buttons[i]);
		}
	}

	public void updateNames(String[] n) // setting the names onto the panels
	{
		buttons = new JButton[listener.getSize()];

		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JButton(n[i]);
			listPanel.add(buttons[i]);
		}

	}

	public void setDescription(String s) // setting the description for the items
	{
	}

	public void addToCart(String entry) // adding the outputs to the cart area
	{
	}

	public String getCart() // gettting the text from the cart
	{
		String result = null; // update this

		return result;
	}
}
