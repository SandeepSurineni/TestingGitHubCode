This file can be any one of the following types 
sample.py
sample.sh
