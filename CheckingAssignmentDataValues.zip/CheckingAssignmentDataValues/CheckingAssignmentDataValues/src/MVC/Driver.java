package MVC;

import java.awt.Dimension;
import java.awt.Window;
import java.util.Set;

public class Driver {

	public static void main(String[] args) {
		GUI frame = new GUI();	//declaring a gui
		
		
		Controller listener = new Controller();	//declaring a controller
		
		//panel should be hooked to the listener
		frame.setlistener(listener);
		//listener should be hooked to panel
		listener.setGUI(frame);		
		frame.setNames(listener.getitemsnames());	//gets the names of the controller		
		listener.invManager.getSize();	//gets the size of the controller
	}
}
