package MVC;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import Products.Item;

public class InventoryManager implements Serializable {

	Item[] items; // declaring the array
	int size = 0;

	public InventoryManager() {
		this.items = new Item[25];
		this.size = 0;
		loadInventory();
	}

	// gets the this.size of the item array
	public int getSize() {
		return this.size;
	}

	// getting the name for a specific item
	public String[] getitemnames() {
		String[] result = new String[this.size];

		for (int i = 0; i < this.size; i++) {
			if(this.items[i] != null)
				result[i] = this.items[i].getName();
		}
		
		System.out.println("Size : " + size);
		
		System.out.println("Item Names : " );
		for(String str :result) {
			System.out.println(str);
		}
		
		return result;
	}

	// 
	public String getItemDescription(String s) {
		String result = null;
		for (int i = 0; i < this.size; i++) {
			if (s.equals(this.items[i].getName())) {
				result = this.items[i].getCode();
			}
		}
		return result;
	}

	public double getPriceandUpdate(String s, int n) {
		double result = 0;
		double price = 0;
		for (int i = 0; i < this.size; i++) {
			if (s.equals(this.items[i].getName())) {
				price = this.items[i].getPrice();
			}
		}
		return price;
	}

	
	/*
	 * Reads Storage.dat file and populates Items[] 
	 */
	public void loadInventory() {
		// open storage.dat
		ObjectInputStream inputfile = null;
		boolean done = false;
		Object o = null;
		int index=0;
		try {
			inputfile = new ObjectInputStream(new FileInputStream("Storage.dat"));
			while (!done) {
				o = inputfile.readObject();
				this.items[index] = (Item) inputfile.readObject();
				System.out.println(" Item : "+ this.items[index]);
				index++;
			}
		} catch(java.io.EOFException e) {
			System.out.println("Inventory Loaded successfully!!!");
		}catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(inputfile != null) {
				try {
					inputfile.close();
				} catch (IOException e) {}
			}
		}
		this.size = index;
		System.out.println("No of Inventory Loaded : "+ size );
	}
	
	/*
	 * Write updates to file
	 */
	public void updateInventory() throws IOException {
		Item item;
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream("Storage.dat"));
			for(int i=0;i<size;i++) {
				item = items[i];
				out.writeObject(item);
			}						
		}catch(Exception e) {
			System.out.println("Error while writing Objects to file"+ e);			
		} finally {
			if(out != null) {
				out.close();
			}
		}
	}
}
